package com.itheima.mobilesafe.monitor.entity;

public class TrafficInfo {
    private String date;
    private String mobiletraffic;
    private String wifi;
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getMobiletraffic() {
        return mobiletraffic;
    }
    public void setMobiletraffic(String mobiletraffic) {
        this.mobiletraffic = mobiletraffic;
    }
    public String getWifi() {
        return wifi;
    }
    public void setWifi(String wifi) {
        this.wifi = wifi;
    }
}
