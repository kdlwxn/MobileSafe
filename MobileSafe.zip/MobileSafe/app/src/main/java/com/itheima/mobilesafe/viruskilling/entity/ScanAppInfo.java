package com.itheima.mobilesafe.viruskilling.entity;

import android.graphics.drawable.Drawable;

public class ScanAppInfo {
    public String appName;       //应用名称
    public boolean isVirus;     //是否是病毒
    public String packagename; //应用包名
    public String description; //应用描述
    public Drawable appicon;   //应用图标
}
